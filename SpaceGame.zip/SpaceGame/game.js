class Game {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.score = 0;
        this.gameOver = false;
        
        // Game objects
        this.spaceship = null;
        this.stars = [];
        this.meteorites = [];
        
        // Sprite images
        this.spaceshipSprite = null;
        this.starSprite = null;
        this.meteoriteSprite = null;
        
        // Game settings
        this.starSpawnRate = 0.02;
        this.meteoriteSpawnRate = 0.03;
        
        // Initialize game
        this.init();
    }
    
    async init() {
        // Show loading message
        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = '24px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText('Loading...', this.canvas.width / 2, this.canvas.height / 2);
        
        try {
            // Load sprites
            this.spaceshipSprite = createSpaceshipSprite();
            this.starSprite = createStarSprite();
            this.meteoriteSprite = createMeteoriteSprite();
            
            // Create spaceship
            this.spaceship = new Spaceship(
                this.canvas.width / 2,
                this.canvas.height - 50,
                this.spaceshipSprite
            );
            
            // Start game loop
            this.gameLoop();
        } catch (error) {
            console.error('Error initializing game:', error);
            this.ctx.fillStyle = '#ff0000';
            this.ctx.fillText('Error loading game assets', this.canvas.width / 2, this.canvas.height / 2 + 30);
        }
    }
    
    spawnStar() {
        if (Math.random() < this.starSpawnRate) {
            const x = Math.random() * (this.canvas.width - 20) + 10;
            this.stars.push(new Star(x, -20, this.starSprite));
        }
    }
    
    spawnMeteorite() {
        if (Math.random() < this.meteoriteSpawnRate) {
            const x = Math.random() * (this.canvas.width - 30) + 15;
            this.meteorites.push(new Meteorite(x, -30, this.meteoriteSprite));
        }
    }
    
    checkCollisions() {
        // Check star collisions
        for (let i = this.stars.length - 1; i >= 0; i--) {
            if (this.spaceship.collidesWith(this.stars[i])) {
                this.score += 10;
                this.stars.splice(i, 1);
            }
        }
        
        // Check meteorite collisions
        for (const meteorite of this.meteorites) {
            if (this.spaceship.collidesWith(meteorite)) {
                this.gameOver = true;
                break;
            }
        }
    }
    
    update() {
        if (this.gameOver) return;
        
        // Update game objects
        this.spaceship.update();
        this.stars.forEach(star => star.update());
        this.meteorites.forEach(meteorite => meteorite.update());
        
        // Remove objects that are off screen
        this.stars = this.stars.filter(star => star.y < this.canvas.height + 20);
        this.meteorites = this.meteorites.filter(meteorite => meteorite.y < this.canvas.height + 30);
        
        // Spawn new objects
        this.spawnStar();
        this.spawnMeteorite();
        
        // Check collisions
        this.checkCollisions();
    }
    
    draw() {
        // Clear canvas
        this.ctx.fillStyle = '#000033';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw game objects
        this.stars.forEach(star => star.draw(this.ctx));
        this.meteorites.forEach(meteorite => meteorite.draw(this.ctx));
        this.spaceship.draw(this.ctx);
        
        // Draw score
        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = '20px Arial';
        this.ctx.textAlign = 'left';
        this.ctx.fillText(`Score: ${this.score}`, 10, 30);
        
        // Draw game over message
        if (this.gameOver) {
            this.ctx.fillStyle = '#ffffff';
            this.ctx.font = '48px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText('Game Over!', this.canvas.width / 2, this.canvas.height / 2);
            this.ctx.font = '24px Arial';
            this.ctx.fillText(`Final Score: ${this.score}`, this.canvas.width / 2, this.canvas.height / 2 + 40);
        }
    }
    
    gameLoop = () => {
        this.update();
        this.draw();
        if (!this.gameOver) {
            requestAnimationFrame(this.gameLoop);
        }
    }
}