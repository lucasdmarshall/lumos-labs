// Function to create spaceship sprite
function createSpaceshipSprite() {
    // Create a canvas element
    const canvas = document.createElement('canvas');
    canvas.width = 64;  // Width of the sprite
    canvas.height = 64; // Height of the sprite
    
    // Get the 2D rendering context
    const ctx = canvas.getContext('2d');
    
    // Clear any existing content and set transparent background
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Center coordinates
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    
    // Save the current context state
    ctx.save();
    
    // Move to center and rotate to point upward
    ctx.translate(centerX, centerY);
    ctx.rotate(-Math.PI / 2); // Rotate to point upward
    
    // Draw the main body (triangle)
    ctx.beginPath();
    ctx.moveTo(0, -20);     // Top point
    ctx.lineTo(15, 20);     // Bottom right
    ctx.lineTo(-15, 20);    // Bottom left
    ctx.closePath();
    
    // Create gradient for the ship body
    const gradient = ctx.createLinearGradient(0, -20, 0, 20);
    gradient.addColorStop(0, '#4a9eff');    // Light blue at top
    gradient.addColorStop(1, '#006fff');    // Darker blue at bottom
    
    // Fill and stroke the main body
    ctx.fillStyle = gradient;
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.fill();
    ctx.stroke();
    
    // Draw the cockpit
    ctx.beginPath();
    ctx.fillStyle = '#ff0000';
    ctx.arc(0, 0, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.stroke();
    
    // Draw engine flames
    ctx.beginPath();
    ctx.moveTo(-8, 20);
    ctx.lineTo(0, 30);
    ctx.lineTo(8, 20);
    ctx.closePath();
    ctx.fillStyle = '#ff7700';
    ctx.fill();
    
    // Restore the context state
    ctx.restore();
    
    // Return as data URL
    try {
        return canvas.toDataURL('image/png');
    } catch (e) {
        console.error('Error creating spaceship sprite:', e);
        return '';
    }
}

class Spaceship {
    constructor(x, y, sprite) {
        this.x = x;
        this.y = y;
        this.width = 64;
        this.height = 64;
        this.speed = 5;
        this.sprite = new Image();
        this.sprite.src = sprite;
        
        // Movement flags
        this.moveLeft = false;
        this.moveRight = false;
        this.moveUp = false;
        this.moveDown = false;
        
        // Set up keyboard event listeners
        document.addEventListener('keydown', this.handleKeyDown.bind(this));
        document.addEventListener('keyup', this.handleKeyUp.bind(this));
    }
    
    handleKeyDown(event) {
        switch(event.key) {
            case 'ArrowLeft':
                this.moveLeft = true;
                break;
            case 'ArrowRight':
                this.moveRight = true;
                break;
            case 'ArrowUp':
                this.moveUp = true;
                break;
            case 'ArrowDown':
                this.moveDown = true;
                break;
        }
    }
    
    handleKeyUp(event) {
        switch(event.key) {
            case 'ArrowLeft':
                this.moveLeft = false;
                break;
            case 'ArrowRight':
                this.moveRight = false;
                break;
            case 'ArrowUp':
                this.moveUp = false;
                break;
            case 'ArrowDown':
                this.moveDown = false;
                break;
        }
    }
    
    update() {
        // Update position based on movement flags
        if (this.moveLeft && this.x > 0) {
            this.x -= this.speed;
        }
        if (this.moveRight && this.x < 800 - this.width) {
            this.x += this.speed;
        }
        if (this.moveUp && this.y > 0) {
            this.y -= this.speed;
        }
        if (this.moveDown && this.y < 600 - this.height) {
            this.y += this.speed;
        }
    }
    
    draw(ctx) {
        ctx.save();
        ctx.translate(this.x + this.width / 2, this.y + this.height / 2);
        
        // Draw the sprite
        ctx.drawImage(
            this.sprite,
            -this.width / 2,
            -this.height / 2,
            this.width,
            this.height
        );
        
        ctx.restore();
    }
    
    collidesWith(object) {
        return (
            this.x < object.x + object.width &&
            this.x + this.width > object.x &&
            this.y < object.y + object.height &&
            this.y + this.height > object.y
        );
    }
}


