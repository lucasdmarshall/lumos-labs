// Function to create meteorite sprite
function createMeteoriteSprite() {
    // Create a canvas element
    const canvas = document.createElement('canvas');
    canvas.width = 48;  // Width of the sprite
    canvas.height = 48; // Height of the sprite
    
    // Get the 2D rendering context
    const ctx = canvas.getContext('2d');
    
    // Clear any existing content
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Center coordinates
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    
    // Save context state
    ctx.save();
    
    // Move to center
    ctx.translate(centerX, centerY);
    
    // Create irregular polygon path for meteorite
    ctx.beginPath();
    const numPoints = 8;
    const baseRadius = 18;
    const variance = 4;
    
    for (let i = 0; i < numPoints; i++) {
        const angle = (i * 2 * Math.PI) / numPoints;
        const radius = baseRadius + (Math.random() * variance * 2 - variance);
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;
        
        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    }
    ctx.closePath();
    
    // Create gradient for meteorite
    const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, baseRadius);
    gradient.addColorStop(0, '#8b4513');    // Saddle brown center
    gradient.addColorStop(0.7, '#654321');  // Darker brown
    gradient.addColorStop(1, '#4a3210');    // Even darker edge
    
    // Fill and stroke the meteorite
    ctx.fillStyle = gradient;
    ctx.strokeStyle = '#2d2016';
    ctx.lineWidth = 2;
    ctx.fill();
    ctx.stroke();
    
    // Add surface details (craters)
    for (let i = 0; i < 4; i++) {
        const angle = Math.random() * Math.PI * 2;
        const distance = Math.random() * baseRadius * 0.7;
        const craterX = Math.cos(angle) * distance;
        const craterY = Math.sin(angle) * distance;
        const craterSize = 2 + Math.random() * 4;
        
        ctx.beginPath();
        ctx.arc(craterX, craterY, craterSize, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        ctx.fill();
    }
    
    // Restore context state
    ctx.restore();
    
    // Return as data URL
    try {
        return canvas.toDataURL('image/png');
    } catch (e) {
        console.error('Error creating meteorite sprite:', e);
        return '';
    }
}

class Meteorite {
    constructor(x, y, sprite) {
        this.x = x;
        this.y = y;
        this.width = 48;
        this.height = 48;
        this.speed = 3;
        this.sprite = new Image();
        this.sprite.src = sprite;
        
        // Rotation properties
        this.rotation = Math.random() * Math.PI * 2;
        this.rotationSpeed = (Math.random() - 0.5) * 0.1;
    }
    
    update() {
        // Move downward
        this.y += this.speed;
        
        // Update rotation
        this.rotation += this.rotationSpeed;
    }
    
    draw(ctx) {
        ctx.save();
        
        // Move to center of sprite for rotation
        ctx.translate(this.x + this.width / 2, this.y + this.height / 2);
        ctx.rotate(this.rotation);
        
        // Draw the sprite
        ctx.drawImage(
            this.sprite,
            -this.width / 2,
            -this.height / 2,
            this.width,
            this.height
        );
        
        ctx.restore();
    }
}