// Function to create star sprite
function createStarSprite() {
    // Create a canvas element
    const canvas = document.createElement('canvas');
    canvas.width = 32;  // Width of the sprite
    canvas.height = 32; // Height of the sprite
    
    // Get the 2D rendering context
    const ctx = canvas.getContext('2d');
    
    // Clear any existing content
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Center coordinates
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    
    // Star properties
    const outerRadius = 12;
    const innerRadius = 6;
    const numPoints = 5;
    
    // Save context state
    ctx.save();
    
    // Move to center
    ctx.translate(centerX, centerY);
    
    // Create star path
    ctx.beginPath();
    for (let i = 0; i < numPoints * 2; i++) {
        const radius = i % 2 === 0 ? outerRadius : innerRadius;
        const angle = (i * Math.PI) / numPoints;
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;
        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    }
    ctx.closePath();
    
    // Create gradient
    const gradient = ctx.createRadialGradient(0, 0, innerRadius, 0, 0, outerRadius);
    gradient.addColorStop(0, '#ffff00');    // Bright yellow center
    gradient.addColorStop(1, '#ffd700');    // Golden yellow edge
    
    // Fill and stroke the star
    ctx.fillStyle = gradient;
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1;
    ctx.fill();
    ctx.stroke();
    
    // Restore context state
    ctx.restore();
    
    // Return as data URL
    try {
        return canvas.toDataURL('image/png');
    } catch (e) {
        console.error('Error creating star sprite:', e);
        return '';
    }
}

class Star {
    constructor(x, y, sprite) {
        this.x = x;
        this.y = y;
        this.width = 32;
        this.height = 32;
        this.speed = 2;
        this.sprite = new Image();
        this.sprite.src = sprite;
        
        // Animation properties
        this.scale = 1;
        this.scaleDirection = 0.02;
        this.minScale = 0.8;
        this.maxScale = 1.2;
    }
    
    update() {
        // Move downward
        this.y += this.speed;
        
        // Update pulsing animation
        this.scale += this.scaleDirection;
        if (this.scale >= this.maxScale || this.scale <= this.minScale) {
            this.scaleDirection *= -1;
        }
    }
    
    draw(ctx) {
        ctx.save();
        
        // Move to center of sprite for scaling
        ctx.translate(this.x + this.width / 2, this.y + this.height / 2);
        ctx.scale(this.scale, this.scale);
        
        // Draw the sprite
        ctx.drawImage(
            this.sprite,
            -this.width / 2,
            -this.height / 2,
            this.width,
            this.height
        );
        
        ctx.restore();
    }
}