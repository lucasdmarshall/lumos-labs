class GameScene extends Phaser.Scene {
    constructor() {
        super('GameScene');
        this.isPaused = false; // Track game pause state
    }

    preload() {
        this.load.image('spaceship', 'spaceship.png');
        this.load.image('enemy', 'enemy.png');
        this.load.image('power', 'power.png');
    }

    create() {
        // Create spaceship with a smaller size
        this.spaceship = this.physics.add.sprite(400, 500, 'spaceship');
        this.spaceship.setScale(0.05);
        this.spaceship.setCollideWorldBounds(true);

        // Create power-up with a smaller size
        this.power = this.physics.add.sprite(200, 300, 'power');
        this.power.setScale(0.05);
        
        // Floating animation for power-up
        this.tweens.add({
            targets: this.power,
            y: this.power.y - 20,
            duration: 1000,
            yoyo: true,
            repeat: -1
        });

        // Create enemy group
        this.enemy = this.physics.add.group();
        this.spawnEnemy();

        // Set up controls
        this.cursors = this.input.keyboard.createCursorKeys();
        
        // Add space key for pause
        this.spaceKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
        
        // Create pause text (hidden by default)
        this.pauseText = this.add.text(400, 300, 'PAUSED', {
            fontSize: '32px',
            fill: '#fff'
        });
        this.pauseText.setOrigin(0.5); // Center the text
        this.pauseText.visible = false;

        // Set up collisions
        this.physics.add.overlap(this.spaceship, this.power, this.collectPower, null, this);
        this.physics.add.collider(this.spaceship, this.enemy, this.hitEnemy, null, this);

        // Initialize score
        this.score = 0;
        this.scoreText = this.add.text(10, 10, 'Score : 0', {
            fontSize: '20px',
            fill: '#fff'
        });

        // Enemy spawn timer
        this.time.addEvent({
            delay: 2000,
            callback: this.spawnEnemy,
            callbackScope: this,
            loop: true
        });
    }

    spawnEnemy() {
        const x = Phaser.Math.Between(50, 750);
        const enemy = this.enemy.create(x, 0, 'enemy');
        enemy.setScale(0.05);
        enemy.setVelocityY(150);
        enemy.setCollideWorldBounds(false);
    }

    collectPower(spaceship, power) {
        this.power.disableBody(true, true);
        this.score += 10;
        this.scoreText.setText('Score : ' + this.score);

        const x = Phaser.Math.Between(50, 750);
        const y = Phaser.Math.Between(100, 400);
        this.power.enableBody(true, x, y, true, true);
    }

    hitEnemy(spaceship, enemy) {
        this.cameras.main.shake(200);
        this.physics.pause();
        spaceship.setTint(0xff0000);
        this.add.text(280, 280, 'Game Over', {
            fontSize: '40px',
            fill: '#fff'
        });
    }

    togglePause() {
        if (this.isPaused) {
            // Resume game
            this.physics.resume();
            this.tweens.resumeAll();
            this.pauseText.visible = false;
        } else {
            // Pause game
            this.physics.pause();
            this.tweens.pauseAll();
            this.pauseText.visible = true;
        }
        this.isPaused = !this.isPaused;
    }

    update() {
        // Check for space key press (for pause)
        if (Phaser.Input.Keyboard.JustDown(this.spaceKey)) {
            this.togglePause();
            return; // Skip rest of update if we just toggled pause
        }

        // If game is paused, don't process other inputs
        if (this.isPaused) return;

        if (this.cursors.left.isDown) {
            this.spaceship.setVelocityX(-160);
        } else if (this.cursors.right.isDown) {
            this.spaceship.setVelocityX(160);
        } else {
            this.spaceship.setVelocityX(0);
        }

        if (this.cursors.up.isDown) {
            this.spaceship.setVelocityY(-160);
        } else if (this.cursors.down.isDown) {
            this.spaceship.setVelocityY(160);
        } else {
            this.spaceship.setVelocityY(0);
        }
    }
}

const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    backgroundColor: 0x000000,
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0 },
            debug: false
        }
    },
    scene: [GameScene]
};

const game = new Phaser.Game(config);
